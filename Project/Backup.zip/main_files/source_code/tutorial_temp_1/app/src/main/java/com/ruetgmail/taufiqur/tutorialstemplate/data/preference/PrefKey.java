package com.ruetgmail.taufiqur.tutorialstemplate.data.preference;

public class PrefKey {
    public static final String APP_PREF_NAME = "offline_tutorial_app";
    public static final String KEY_SOUND = "sound";
}
