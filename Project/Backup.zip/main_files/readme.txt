Source Code Link of This App: https://codecanyon.net/item/tutorial-app-with-quiz-native-android-offline-learning-app-with-admob-firebase-push-notification/21497628

More Apps with Source Code: https://codecanyon.net/user/loser-leo/portfolio

Details Online Documentation Link: https://docs.google.com/document/d/1qwWg_U3jCkmG-W8XQgIrz7gOrwTuW4iizOWcH0xFPTY/edit?usp=sharing